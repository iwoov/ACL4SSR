import Database from "better-sqlite3";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(__dirname, "..", "data");

// Ensure data directory exists
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, "benchmark.db");
const db = new Database(dbPath);

// Enable WAL mode for better performance
db.pragma("journal_mode = WAL");

// Create table
db.exec(`
  CREATE TABLE IF NOT EXISTS column_prefs (
    file_name TEXT PRIMARY KEY,
    selected_keys TEXT NOT NULL,
    field_signature TEXT,
    editable_keys TEXT
  );
`);

const tableColumns = db
  .prepare("PRAGMA table_info(column_prefs)")
  .all() as Array<{ name: string }>;
const hasFieldSignatureColumn = tableColumns.some(
  (column) => column.name === "field_signature",
);
const hasEditableKeysColumn = tableColumns.some(
  (column) => column.name === "editable_keys",
);

if (!hasFieldSignatureColumn) {
  db.exec("ALTER TABLE column_prefs ADD COLUMN field_signature TEXT");
}
if (!hasEditableKeysColumn) {
  db.exec("ALTER TABLE column_prefs ADD COLUMN editable_keys TEXT");
}

export interface ColumnPrefsConfig {
  fieldSignature: string;
  displayKeys: string[];
  editableKeys: string[];
}

function parseJsonStringArray(value: string | null | undefined): string[] {
  if (!value) {
    return [];
  }
  try {
    const parsed = JSON.parse(value) as unknown;
    if (!Array.isArray(parsed)) {
      return [];
    }
    return parsed.filter((item): item is string => typeof item === "string");
  } catch {
    return [];
  }
}

/**
 * Get saved column preferences for a given file name.
 * Returns null if not found.
 */
export function getColumnPrefs(fileName: string): ColumnPrefsConfig | null {
  const row = db
    .prepare(
      "SELECT selected_keys, field_signature, editable_keys FROM column_prefs WHERE file_name = ?",
    )
    .get(fileName) as
    | {
        selected_keys: string;
        field_signature: string | null;
        editable_keys: string | null;
      }
    | undefined;

  if (!row) {
    return null;
  }

  return {
    fieldSignature: row.field_signature ?? "",
    displayKeys: parseJsonStringArray(row.selected_keys),
    editableKeys: parseJsonStringArray(row.editable_keys),
  };
}

/**
 * Save (upsert) column preferences for a given file name.
 */
export function saveColumnPrefs(
  fileName: string,
  config: ColumnPrefsConfig,
): void {
  db.prepare(
    `INSERT INTO column_prefs (file_name, selected_keys, field_signature, editable_keys)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(file_name) DO UPDATE SET
       selected_keys = excluded.selected_keys,
       field_signature = excluded.field_signature,
       editable_keys = excluded.editable_keys`,
  ).run(
    fileName,
    JSON.stringify(config.displayKeys),
    config.fieldSignature,
    JSON.stringify(config.editableKeys),
  );
}

export default db;
