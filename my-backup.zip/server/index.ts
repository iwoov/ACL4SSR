import cors from "cors";
import express from "express";
import * as ExcelJS from "exceljs";
import multer from "multer";
import { randomUUID } from "node:crypto";
import { parseWorkbook } from "./excelParser.js";
import { getColumnPrefs, saveColumnPrefs } from "./db.js";

type ExcelJSImportLike = { Workbook: new () => ExcelJS.Workbook };
const ExcelJSRuntime: ExcelJSImportLike =
  (ExcelJS as unknown as { default?: ExcelJSImportLike }).default ??
  (ExcelJS as unknown as ExcelJSImportLike);

const app = express();
const port = 8787;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 25 * 1024 * 1024,
  },
});

app.use(cors());
app.use(express.json({ limit: "20mb" }));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    timestamp: new Date().toISOString(),
  });
});

app.post("/api/files/upload", upload.single("file"), async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({
        message: "请先选择 Excel 文件",
      });
    }

    const fileId = randomUUID();
    const parsed = await parseWorkbook(file.buffer, file.originalname, fileId);
    return res.json(parsed);
  } catch (error) {
    const message = error instanceof Error ? error.message : "解析 Excel 失败";
    return res.status(400).json({ message });
  }
});

// ─── Column Preferences ───

app.get("/api/column-prefs/:fileName", (req, res) => {
  const { fileName } = req.params;
  const config = getColumnPrefs(decodeURIComponent(fileName));
  return res.json({ config });
});

app.put("/api/column-prefs/:fileName", (req, res) => {
  const { fileName } = req.params;
  const { fieldSignature, displayKeys, editableKeys } = req.body as {
    fieldSignature: unknown;
    displayKeys: unknown;
    editableKeys: unknown;
  };

  if (
    typeof fieldSignature !== "string" ||
    fieldSignature.trim().length === 0
  ) {
    return res
      .status(400)
      .json({ message: "fieldSignature must be a non-empty string" });
  }
  if (
    !Array.isArray(displayKeys) ||
    !displayKeys.every((item) => typeof item === "string")
  ) {
    return res
      .status(400)
      .json({ message: "displayKeys must be a string array" });
  }
  if (
    !Array.isArray(editableKeys) ||
    !editableKeys.every((item) => typeof item === "string")
  ) {
    return res
      .status(400)
      .json({ message: "editableKeys must be a string array" });
  }

  saveColumnPrefs(decodeURIComponent(fileName), {
    fieldSignature,
    displayKeys,
    editableKeys,
  });
  return res.json({ ok: true });
});

app.post("/api/files/export", async (req, res) => {
  const { fileName, headers, rows } = req.body as {
    fileName: unknown;
    headers: unknown;
    rows: unknown;
  };

  if (typeof fileName !== "string" || fileName.trim().length === 0) {
    return res
      .status(400)
      .json({ message: "fileName must be a non-empty string" });
  }
  if (
    !Array.isArray(headers) ||
    !headers.every((item) => typeof item === "string")
  ) {
    return res.status(400).json({ message: "headers must be a string array" });
  }
  if (
    !Array.isArray(rows) ||
    !rows.every(
      (row) =>
        Array.isArray(row) && row.every((cell) => typeof cell === "string"),
    )
  ) {
    return res.status(400).json({ message: "rows must be a 2d string array" });
  }

  try {
    const workbook = new ExcelJSRuntime.Workbook();
    const worksheet = workbook.addWorksheet("Sheet1");

    worksheet.addRow(headers);
    for (const row of rows) {
      worksheet.addRow(row);
    }

    worksheet.columns = headers.map((header, index) => {
      const maxLengthFromRows = rows.reduce((acc, row) => {
        const value = row[index] ?? "";
        return Math.max(acc, value.length);
      }, 0);
      return {
        header,
        key: `col_${index}`,
        width: Math.min(
          60,
          Math.max(12, Math.max(header.length, maxLengthFromRows) + 2),
        ),
      };
    });

    const headerRow = worksheet.getRow(1);
    headerRow.font = { bold: true };
    headerRow.commit();

    const baseName = fileName.replace(/\.[^.]+$/, "");
    const exportName = `${baseName}-导出.xlsx`;
    const encodedFileName = encodeURIComponent(exportName);
    const buffer = await workbook.xlsx.writeBuffer();

    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename*=UTF-8''${encodedFileName}`,
    );
    const outputBuffer = Buffer.isBuffer(buffer)
      ? buffer
      : Buffer.from(buffer as ArrayBuffer);
    return res.send(outputBuffer);
  } catch (error) {
    const message = error instanceof Error ? error.message : "导出 Excel 失败";
    return res.status(500).json({ message });
  }
});

app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`Server running at http://localhost:${port}`);
});
