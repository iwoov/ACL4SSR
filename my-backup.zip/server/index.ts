import cors from "cors";
import express from "express";
import * as ExcelJS from "exceljs";
import multer from "multer";
import { randomUUID } from "node:crypto";
import { parseWorkbook } from "./excelParser.js";
import {
  getAIDetectConfig,
  deleteFileState,
  getColumnPrefs,
  listFileStates,
  saveAIDetectConfig,
  saveColumnPrefs,
  saveFileState,
} from "./db.js";

type ExcelJSImportLike = { Workbook: new () => ExcelJS.Workbook };
const ExcelJSRuntime: ExcelJSImportLike =
  (ExcelJS as unknown as { default?: ExcelJSImportLike }).default ??
  (ExcelJS as unknown as ExcelJSImportLike);

const app = express();
const port = 8787;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 25 * 1024 * 1024,
  },
});

app.use(cors());
app.use(express.json({ limit: "100mb" }));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    timestamp: new Date().toISOString(),
  });
});

function normalizeUploadedFileName(fileName: string): string {
  const decoded = Buffer.from(fileName, "latin1").toString("utf8");
  if (decoded.includes("�")) {
    return fileName;
  }
  return decoded;
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function normalizeOpenAIUrl(rawUrl: string): string {
  const trimmed = rawUrl.trim();
  if (trimmed.length === 0) {
    return "";
  }

  const normalized = trimmed.replace(/\/+$/, "");
  if (/\/chat\/completions$/i.test(normalized)) {
    return normalized;
  }
  if (/\/v1$/i.test(normalized)) {
    return `${normalized}/chat/completions`;
  }
  return `${normalized}/v1/chat/completions`;
}

type AIDetectField = {
  title: string;
  type: "text" | "image";
  value: string;
  imageUrl?: string;
};

type OpenAIMessageContentPart =
  | {
      type: "text";
      text: string;
    }
  | {
      type: "image_url";
      image_url: { url: string };
    };

type PromptBuildResult = {
  promptText: string;
  imageFields: Array<{ title: string; value: string; imageUrl: string }>;
};

function toAIDetectFields(value: unknown): AIDetectField[] | null {
  if (!Array.isArray(value)) {
    return null;
  }

  const result: AIDetectField[] = [];
  for (const item of value) {
    if (!item || typeof item !== "object" || Array.isArray(item)) {
      return null;
    }

    const candidate = item as {
      title?: unknown;
      type?: unknown;
      value?: unknown;
      imageUrl?: unknown;
    };

    if (
      typeof candidate.title !== "string" ||
      candidate.title.trim().length === 0
    ) {
      return null;
    }
    if (candidate.type !== "text" && candidate.type !== "image") {
      return null;
    }
    if (candidate.value !== undefined && typeof candidate.value !== "string") {
      return null;
    }
    if (candidate.type === "image") {
      if (
        typeof candidate.imageUrl !== "string" ||
        candidate.imageUrl.trim().length === 0
      ) {
        return null;
      }
      result.push({
        title: candidate.title.trim(),
        type: "image",
        value: typeof candidate.value === "string" ? candidate.value : "",
        imageUrl: candidate.imageUrl,
      });
      continue;
    }

    result.push({
      title: candidate.title.trim(),
      type: "text",
      value: typeof candidate.value === "string" ? candidate.value : "",
    });
  }

  return result;
}

function buildPromptContent(
  prompt: string,
  fields: AIDetectField[],
): PromptBuildResult {
  const fieldSummary: Record<string, string> = {};
  const imageFields: Array<{ title: string; value: string; imageUrl: string }> =
    [];

  fields.forEach((field) => {
    if (field.type === "image" && field.imageUrl) {
      const summary =
        field.value.trim().length > 0 ? `[图片] ${field.value}` : "[图片]";
      fieldSummary[field.title] = summary;
      imageFields.push({
        title: field.title,
        value: field.value,
        imageUrl: field.imageUrl,
      });
      return;
    }
    fieldSummary[field.title] = field.value;
  });

  const fieldsJson = JSON.stringify(fieldSummary, null, 2);
  const fieldsText = Object.entries(fieldSummary)
    .map(([key, value]) => `${key}: ${value || "-"}`)
    .join("\n");
  const imageFieldsText =
    imageFields.length > 0
      ? imageFields
          .map((field) =>
            field.value.trim().length > 0
              ? `${field.title}（说明：${field.value}）`
              : field.title,
          )
          .join("、")
      : "无";

  const hasJsonPlaceholder = prompt.includes("{{fields_json}}");
  const hasTextPlaceholder = prompt.includes("{{fields_text}}");
  const hasImagePlaceholder = prompt.includes("{{image_fields}}");

  const mergedPrompt = prompt
    .replaceAll("{{fields_json}}", fieldsJson)
    .replaceAll("{{fields_text}}", fieldsText)
    .replaceAll("{{image_fields}}", imageFieldsText);

  if (hasJsonPlaceholder || hasTextPlaceholder) {
    return {
      promptText: mergedPrompt,
      imageFields,
    };
  }

  const withImageHint =
    hasImagePlaceholder || imageFields.length === 0
      ? mergedPrompt
      : `${mergedPrompt}\n\n图片字段：${imageFieldsText}`;

  return {
    promptText: `${withImageHint.trim()}\n\n待检测字段(JSON):\n${fieldsJson}`,
    imageFields,
  };
}

app.post("/api/files/upload", upload.single("file"), async (req, res) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({
        message: "请先选择 Excel 文件",
      });
    }

    const fileId = randomUUID();
    const normalizedFileName = normalizeUploadedFileName(file.originalname);
    const parsed = await parseWorkbook(file.buffer, normalizedFileName, fileId);
    return res.json(parsed);
  } catch (error) {
    const message = error instanceof Error ? error.message : "解析 Excel 失败";
    return res.status(400).json({ message });
  }
});

app.get("/api/files", (_req, res) => {
  const files = listFileStates().map((item) => item.state);
  return res.json({ files });
});

app.put("/api/files/:fileId/state", (req, res) => {
  const { fileId } = req.params;
  const { state } = req.body as { state?: unknown };

  if (!state || typeof state !== "object") {
    return res.status(400).json({ message: "state must be an object" });
  }

  const nextState = state as { fileId?: unknown; fileName?: unknown };
  if (typeof nextState.fileId !== "string" || nextState.fileId !== fileId) {
    return res
      .status(400)
      .json({ message: "state.fileId must match route fileId" });
  }
  if (
    typeof nextState.fileName !== "string" ||
    nextState.fileName.trim().length === 0
  ) {
    return res
      .status(400)
      .json({ message: "state.fileName must be a non-empty string" });
  }

  saveFileState(fileId, nextState.fileName, state);
  return res.json({ ok: true });
});

app.delete("/api/files/:fileId", (req, res) => {
  const { fileId } = req.params;
  deleteFileState(fileId);
  return res.json({ ok: true });
});

// ─── Column Preferences ───

app.get("/api/column-prefs/:fileName", (req, res) => {
  const { fileName } = req.params;
  const config = getColumnPrefs(decodeURIComponent(fileName));
  return res.json({ config });
});

app.put("/api/column-prefs/:fileName", (req, res) => {
  const { fileName } = req.params;
  const { fieldSignature, displayKeys, editableKeys } = req.body as {
    fieldSignature: unknown;
    displayKeys: unknown;
    editableKeys: unknown;
  };

  if (
    typeof fieldSignature !== "string" ||
    fieldSignature.trim().length === 0
  ) {
    return res
      .status(400)
      .json({ message: "fieldSignature must be a non-empty string" });
  }
  if (
    !Array.isArray(displayKeys) ||
    !displayKeys.every((item) => typeof item === "string")
  ) {
    return res
      .status(400)
      .json({ message: "displayKeys must be a string array" });
  }
  if (
    !Array.isArray(editableKeys) ||
    !editableKeys.every((item) => typeof item === "string")
  ) {
    return res
      .status(400)
      .json({ message: "editableKeys must be a string array" });
  }

  saveColumnPrefs(decodeURIComponent(fileName), {
    fieldSignature,
    displayKeys,
    editableKeys,
  });
  return res.json({ ok: true });
});

// ─── AI Detection Config ───

app.get("/api/ai-config/:fileName", (req, res) => {
  const { fileName } = req.params;
  const config = getAIDetectConfig(decodeURIComponent(fileName));
  return res.json({ config });
});

app.put("/api/ai-config/:fileName", (req, res) => {
  const { fileName } = req.params;
  const { url, model, apiKey, submitFieldKeys, prompt, resultFieldKey } =
    req.body as {
      url: unknown;
      model: unknown;
      apiKey: unknown;
      submitFieldKeys: unknown;
      prompt: unknown;
      resultFieldKey?: unknown;
    };

  if (!isNonEmptyString(url)) {
    return res.status(400).json({ message: "url must be a non-empty string" });
  }
  if (!isNonEmptyString(model)) {
    return res
      .status(400)
      .json({ message: "model must be a non-empty string" });
  }
  if (!isNonEmptyString(apiKey)) {
    return res
      .status(400)
      .json({ message: "apiKey must be a non-empty string" });
  }
  if (
    !Array.isArray(submitFieldKeys) ||
    !submitFieldKeys.every((item) => typeof item === "string")
  ) {
    return res
      .status(400)
      .json({ message: "submitFieldKeys must be a string array" });
  }
  if (!isNonEmptyString(prompt)) {
    return res
      .status(400)
      .json({ message: "prompt must be a non-empty string" });
  }
  if (resultFieldKey !== undefined && typeof resultFieldKey !== "string") {
    return res.status(400).json({ message: "resultFieldKey must be a string" });
  }

  saveAIDetectConfig(decodeURIComponent(fileName), {
    url,
    model,
    apiKey,
    submitFieldKeys,
    prompt,
    resultFieldKey: typeof resultFieldKey === "string" ? resultFieldKey : "",
  });

  return res.json({ ok: true });
});

// ─── AI Detection Stream ───

app.post("/api/ai-detect/stream", async (req, res) => {
  const { url, model, apiKey, prompt, fields } = req.body as {
    url: unknown;
    model: unknown;
    apiKey: unknown;
    prompt: unknown;
    fields: unknown;
  };

  if (!isNonEmptyString(url)) {
    return res.status(400).json({ message: "url must be a non-empty string" });
  }
  if (!isNonEmptyString(model)) {
    return res
      .status(400)
      .json({ message: "model must be a non-empty string" });
  }
  if (!isNonEmptyString(apiKey)) {
    return res
      .status(400)
      .json({ message: "apiKey must be a non-empty string" });
  }
  if (!isNonEmptyString(prompt)) {
    return res
      .status(400)
      .json({ message: "prompt must be a non-empty string" });
  }

  const fieldPayload = toAIDetectFields(fields);
  if (!fieldPayload || fieldPayload.length === 0) {
    return res
      .status(400)
      .json({ message: "fields must be a non-empty array" });
  }

  const targetUrl = normalizeOpenAIUrl(url);
  try {
    // Validate URL before dispatching request.
    new URL(targetUrl);
  } catch {
    return res.status(400).json({ message: "url is invalid" });
  }

  const controller = new AbortController();
  req.on("close", () => controller.abort());

  try {
    const promptContent = buildPromptContent(prompt, fieldPayload);
    const userContent: string | OpenAIMessageContentPart[] =
      promptContent.imageFields.length > 0
        ? [
            {
              type: "text",
              text: promptContent.promptText,
            },
            ...promptContent.imageFields.flatMap((field) => {
              const imageLabel =
                field.value.trim().length > 0
                  ? `字段图片：${field.title}（说明：${field.value}）`
                  : `字段图片：${field.title}`;
              return [
                {
                  type: "text" as const,
                  text: imageLabel,
                },
                {
                  type: "image_url" as const,
                  image_url: {
                    url: field.imageUrl,
                  },
                },
              ];
            }),
          ]
        : promptContent.promptText;

    const upstream = await fetch(targetUrl, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        stream: true,
        messages: [{ role: "user", content: userContent }],
      }),
    });

    if (!upstream.ok || !upstream.body) {
      const rawText = await upstream.text().catch(() => "");
      let message = "AI 检测请求失败";
      if (rawText.length > 0) {
        try {
          const payload = JSON.parse(rawText) as {
            error?: { message?: string };
            message?: string;
          };
          message = payload.error?.message ?? payload.message ?? message;
        } catch {
          message = rawText.slice(0, 400);
        }
      }
      return res.status(upstream.status || 500).json({ message });
    }

    res.status(200);
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders();

    const decoder = new TextDecoder();
    let buffer = "";

    const reader = upstream.body.getReader();
    while (true) {
      const { value, done } = await reader.read();
      if (done) {
        break;
      }
      if (!value) {
        continue;
      }

      const current = decoder.decode(value, { stream: true });
      buffer += current;

      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() ?? "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) {
          continue;
        }

        const data = trimmed.slice(5).trim();
        if (data === "[DONE]") {
          res.end();
          return;
        }
        if (data.length === 0) {
          continue;
        }

        try {
          const payload = JSON.parse(data) as {
            choices?: Array<{
              delta?: { content?: string };
              message?: { content?: string };
            }>;
          };
          const text =
            payload.choices?.[0]?.delta?.content ??
            payload.choices?.[0]?.message?.content ??
            "";
          if (typeof text === "string" && text.length > 0) {
            res.write(text);
          }
        } catch {
          // Ignore non-JSON stream chunks.
        }
      }
    }

    buffer += decoder.decode();

    if (buffer.length > 0 && buffer.includes("data:")) {
      const maybeData = buffer
        .split(/\r?\n/)
        .map((line) => line.trim())
        .find((line) => line.startsWith("data:"));
      const value = maybeData ? maybeData.slice(5).trim() : "";
      if (value && value !== "[DONE]") {
        try {
          const payload = JSON.parse(value) as {
            choices?: Array<{
              delta?: { content?: string };
              message?: { content?: string };
            }>;
          };
          const text =
            payload.choices?.[0]?.delta?.content ??
            payload.choices?.[0]?.message?.content ??
            "";
          if (typeof text === "string" && text.length > 0) {
            res.write(text);
          }
        } catch {
          // Ignore trailing invalid chunk.
        }
      }
    }

    res.end();
    return;
  } catch (error) {
    if (controller.signal.aborted) {
      return;
    }
    const message = error instanceof Error ? error.message : "AI 检测请求失败";
    return res.status(500).json({ message });
  }
});

app.post("/api/files/export", async (req, res) => {
  const { fileName, headers, rows } = req.body as {
    fileName: unknown;
    headers: unknown;
    rows: unknown;
  };

  if (typeof fileName !== "string" || fileName.trim().length === 0) {
    return res
      .status(400)
      .json({ message: "fileName must be a non-empty string" });
  }
  if (
    !Array.isArray(headers) ||
    !headers.every((item) => typeof item === "string")
  ) {
    return res.status(400).json({ message: "headers must be a string array" });
  }
  if (
    !Array.isArray(rows) ||
    !rows.every(
      (row) =>
        Array.isArray(row) && row.every((cell) => typeof cell === "string"),
    )
  ) {
    return res.status(400).json({ message: "rows must be a 2d string array" });
  }

  try {
    const workbook = new ExcelJSRuntime.Workbook();
    const worksheet = workbook.addWorksheet("Sheet1");

    worksheet.addRow(headers);
    for (const row of rows) {
      worksheet.addRow(row);
    }

    worksheet.columns = headers.map((header, index) => {
      const maxLengthFromRows = rows.reduce((acc, row) => {
        const value = row[index] ?? "";
        return Math.max(acc, value.length);
      }, 0);
      return {
        header,
        key: `col_${index}`,
        width: Math.min(
          60,
          Math.max(12, Math.max(header.length, maxLengthFromRows) + 2),
        ),
      };
    });

    const headerRow = worksheet.getRow(1);
    headerRow.font = { bold: true };
    headerRow.commit();

    const baseName = fileName.replace(/\.[^.]+$/, "");
    const exportName = `${baseName}-导出.xlsx`;
    const encodedFileName = encodeURIComponent(exportName);
    const buffer = await workbook.xlsx.writeBuffer();

    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename*=UTF-8''${encodedFileName}`,
    );
    const outputBuffer = Buffer.isBuffer(buffer)
      ? buffer
      : Buffer.from(buffer as ArrayBuffer);
    return res.send(outputBuffer);
  } catch (error) {
    const message = error instanceof Error ? error.message : "导出 Excel 失败";
    return res.status(500).json({ message });
  }
});

app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`Server running at http://localhost:${port}`);
});
