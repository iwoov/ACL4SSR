import * as ExcelJS from "exceljs";
import JSZip from "jszip";
import type {
  ParsedCell,
  ParsedColumn,
  ParsedRow,
  ParsedWorkbook,
} from "./types.js";

type ExcelJSImportLike = { Workbook: new () => ExcelJS.Workbook };
const ExcelJSRuntime: ExcelJSImportLike =
  (ExcelJS as unknown as { default?: ExcelJSImportLike }).default ??
  (ExcelJS as unknown as ExcelJSImportLike);

const LEVEL1_ALIASES = ["level1"];
const LEVEL2_ALIASES = ["level2"];

interface ColumnRuntimeMeta extends ParsedColumn {
  colNumber: number;
}

function normalizeHeaderTitle(value: string): string {
  return value.replace(/\s+/g, "").toLowerCase();
}

function matchesHeader(title: string, aliases: string[]): boolean {
  const normalizedTitle = normalizeHeaderTitle(title);
  return aliases.some(
    (alias) => normalizeHeaderTitle(alias) === normalizedTitle,
  );
}

function isRequiredFilterHeader(title: string): boolean {
  return (
    matchesHeader(title, LEVEL1_ALIASES) || matchesHeader(title, LEVEL2_ALIASES)
  );
}

function normalizeCellText(value: ExcelJS.CellValue): string {
  if (value === null || value === undefined) {
    return "";
  }

  if (typeof value === "string") {
    return value.trim();
  }

  if (typeof value === "number" || typeof value === "boolean") {
    return String(value);
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  if (typeof value === "object") {
    if ("richText" in value && Array.isArray(value.richText)) {
      return value.richText
        .map((item) => item.text)
        .join("")
        .trim();
    }

    if ("hyperlink" in value) {
      const text =
        "text" in value && typeof value.text === "string" ? value.text : "";
      if (text) {
        return text.trim();
      }
      return typeof value.hyperlink === "string" ? value.hyperlink.trim() : "";
    }

    if ("formula" in value) {
      const formulaResult = "result" in value ? value.result : "";
      return normalizeCellText(formulaResult as ExcelJS.CellValue);
    }

    if ("error" in value) {
      return "";
    }

    if ("text" in value && typeof value.text === "string") {
      return value.text.trim();
    }

    // Fallback: avoid [object Object]
    const str = String(value);
    if (str === "[object Object]") {
      return "";
    }
    return str.trim();
  }

  return String(value).trim();
}

function detectHeaderRow(worksheet: ExcelJS.Worksheet): number {
  const probeLimit = Math.max(1, Math.min(worksheet.rowCount, 25));
  let bestIndex = 1;
  let bestScore = -1;

  for (let rowIndex = 1; rowIndex <= probeLimit; rowIndex += 1) {
    const row = worksheet.getRow(rowIndex);
    const rowValues = Array.isArray(row.values) ? row.values.slice(1) : [];
    const texts = rowValues
      .map((item: ExcelJS.CellValue | undefined) =>
        normalizeCellText((item ?? null) as ExcelJS.CellValue),
      )
      .filter((value: string) => Boolean(value));

    const hasFilterHeaders = texts.some((value) =>
      isRequiredFilterHeader(value),
    )
      ? 1
      : 0;
    const score = texts.length + hasFilterHeaders * 100;

    if (score > bestScore) {
      bestScore = score;
      bestIndex = rowIndex;
    }
  }

  return bestIndex;
}

function buildColumns(headerRow: ExcelJS.Row): ColumnRuntimeMeta[] {
  const columns: ColumnRuntimeMeta[] = [];

  headerRow.eachCell({ includeEmpty: false }, (cell, colNumber) => {
    const title = normalizeCellText(cell.value);
    if (!title) {
      return;
    }

    columns.push({
      key: `col_${colNumber}`,
      title,
      editable: false,
      required: isRequiredFilterHeader(title),
      colNumber,
    });
  });

  return columns;
}

function getImageDataUrl(
  workbook: ExcelJS.Workbook,
  imageId: number,
): string | undefined {
  const image = workbook.getImage(imageId);
  if (!image) {
    return undefined;
  }

  if (!("buffer" in image) || !image.buffer || !("extension" in image)) {
    return undefined;
  }

  const imageBuffer = Buffer.isBuffer(image.buffer)
    ? image.buffer
    : Buffer.from(image.buffer);
  return `data:image/${image.extension};base64,${imageBuffer.toString("base64")}`;
}

function buildImageMap(
  worksheet: ExcelJS.Worksheet,
  workbook: ExcelJS.Workbook,
): Map<string, string> {
  const imageMap = new Map<string, string>();
  const images = worksheet.getImages();

  for (const image of images) {
    if (typeof image.range === "string") {
      continue;
    }

    const imageId = Number(image.imageId);
    if (Number.isNaN(imageId)) {
      continue;
    }

    const imageUrl = getImageDataUrl(workbook, imageId);
    if (!imageUrl) {
      continue;
    }

    const tl = image.range.tl as {
      row?: number;
      col?: number;
      nativeRow?: number;
      nativeCol?: number;
    };

    const row = Math.floor((tl.nativeRow ?? tl.row ?? 0) + 1);
    const col = Math.floor((tl.nativeCol ?? tl.col ?? 0) + 1);
    imageMap.set(`${row}:${col}`, imageUrl);
  }

  return imageMap;
}

/* ─── "Place in Cell" image extraction (Excel 365) ─── */

function colLetterToNumber(letters: string): number {
  let num = 0;
  for (let i = 0; i < letters.length; i++) {
    num = num * 26 + (letters.charCodeAt(i) - 64);
  }
  return num;
}

function getExtMimeType(ext: string): string {
  const map: Record<string, string> = {
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    gif: "image/gif",
    bmp: "image/bmp",
    webp: "image/webp",
    svg: "image/svg+xml",
    tiff: "image/tiff",
    tif: "image/tiff",
    emf: "image/emf",
    wmf: "image/wmf",
  };
  return map[ext.toLowerCase()] || `image/${ext}`;
}

async function extractPlaceInCellImages(
  buffer: Buffer,
): Promise<Map<string, string>> {
  const imageMap = new Map<string, string>();

  try {
    const zip = await JSZip.loadAsync(buffer);

    // Step 1: Read richValueRel relationships → maps rId to media file path
    const relsPath = "xl/richData/_rels/richValueRel.xml.rels";
    const relsContent = await zip.file(relsPath)?.async("string");
    if (!relsContent) return imageMap;

    const relIdToMedia = new Map<string, string>();
    const relRegex = /Relationship[^>]+Id="(rId\d+)"[^>]+Target="([^"]+)"/g;
    let relMatch;
    while ((relMatch = relRegex.exec(relsContent)) !== null) {
      // Target is relative like "../media/image1.png"
      const target = relMatch[2].replace(/^\.\.\//, "xl/");
      relIdToMedia.set(relMatch[1], target);
    }
    if (relIdToMedia.size === 0) return imageMap;

    // Step 2: Read richValueRel.xml → ordered list of rId references
    const richValueRelContent = await zip
      .file("xl/richData/richValueRel.xml")
      ?.async("string");
    if (!richValueRelContent) return imageMap;

    const orderedRelIds: string[] = [];
    const relRefRegex = /r:id="(rId\d+)"/g;
    let refMatch;
    while ((refMatch = relRefRegex.exec(richValueRelContent)) !== null) {
      orderedRelIds.push(refMatch[1]);
    }
    if (orderedRelIds.length === 0) return imageMap;

    // Step 3: Read rdrichvalue.xml → each <rv> entry, extract first <v> as relIndex
    const rdContent = await zip
      .file("xl/richData/rdrichvalue.xml")
      ?.async("string");
    if (!rdContent) return imageMap;

    // Extract each <rv ...>...</rv> and get the first <v>N</v> value
    const rvEntries: number[] = [];
    const rvRegex = /<rv\b[^>]*>[\s\S]*?<\/rv>/g;
    let rvMatch;
    while ((rvMatch = rvRegex.exec(rdContent)) !== null) {
      const vMatch = /<v>(\d+)<\/v>/.exec(rvMatch[0]);
      if (vMatch) {
        rvEntries.push(parseInt(vMatch[1], 10));
      }
    }

    // Step 4: Read metadata.xml → map vm index to rv index
    const metadataContent = await zip.file("xl/metadata.xml")?.async("string");

    // Build vm→rvIndex mapping from metadata
    // cellMetadata has <bk> entries, each with <rc t="1" v="N"/>
    // futureMetadata has <bk> entries, each with an rvb i="N" child
    let vmToRvIndex: Map<number, number> | undefined;

    if (metadataContent) {
      // Extract futureMetadata entries: <bk>...<rvb i="N"/>...</bk>
      const futureEntries: number[] = [];
      const futureSection = metadataContent.match(
        /<futureMetadata[^>]*name="XLRICHVALUE"[^>]*>[\s\S]*?<\/futureMetadata>/,
      );
      if (futureSection) {
        const bkRegex = /<bk>[\s\S]*?<\/bk>/g;
        let bkMatch;
        while ((bkMatch = bkRegex.exec(futureSection[0])) !== null) {
          const rvbMatch = /i="(\d+)"/.exec(bkMatch[0]);
          if (rvbMatch) {
            futureEntries.push(parseInt(rvbMatch[1], 10));
          }
        }
      }

      // Extract cellMetadata entries: <bk><rc t="1" v="N"/></bk>
      const cellSection = metadataContent.match(
        /<cellMetadata[^>]*>[\s\S]*?<\/cellMetadata>/,
      );
      if (cellSection && futureEntries.length > 0) {
        vmToRvIndex = new Map();
        const bkRegex = /<bk>[\s\S]*?<\/bk>/g;
        let bkMatch;
        let vmIdx = 0;
        while ((bkMatch = bkRegex.exec(cellSection[0])) !== null) {
          const rcMatch = /v="(\d+)"/.exec(bkMatch[0]);
          if (rcMatch) {
            const futureIdx = parseInt(rcMatch[1], 10);
            if (futureIdx < futureEntries.length) {
              vmToRvIndex.set(vmIdx + 1, futureEntries[futureIdx]); // vm is 1-indexed
            }
          }
          vmIdx++;
        }
      }
    }

    // Step 5: Read worksheet XML → find cells with vm="N"
    const sheetFile =
      zip.file("xl/worksheets/sheet1.xml") ??
      zip.file("xl/worksheets/sheet.xml");
    if (!sheetFile) return imageMap;

    const sheetContent = await sheetFile.async("string");
    // Match cells: <c r="D3" ... vm="1" ...>
    const cellRegex = /<c\s+[^>]*r="([A-Z]+)(\d+)"[^>]*vm="(\d+)"[^>]*/g;
    let cellMatch;

    while ((cellMatch = cellRegex.exec(sheetContent)) !== null) {
      const colLetter = cellMatch[1];
      const rowNum = parseInt(cellMatch[2], 10);
      const vmIndex = parseInt(cellMatch[3], 10);

      // Resolve vm → rv index
      let rvIndex: number;
      if (vmToRvIndex && vmToRvIndex.has(vmIndex)) {
        rvIndex = vmToRvIndex.get(vmIndex)!;
      } else {
        // Fallback: direct mapping vm-1 = rvIndex
        rvIndex = vmIndex - 1;
      }

      if (rvIndex < 0 || rvIndex >= rvEntries.length) continue;

      const relIndex = rvEntries[rvIndex];
      if (relIndex >= orderedRelIds.length) continue;

      const relId = orderedRelIds[relIndex];
      const mediaPath = relIdToMedia.get(relId);
      if (!mediaPath) continue;

      const mediaFile = zip.file(mediaPath);
      if (!mediaFile) continue;

      const imgBuffer = await mediaFile.async("nodebuffer");
      const ext = mediaPath.split(".").pop() || "png";
      const mimeType = getExtMimeType(ext);
      const dataUrl = `data:${mimeType};base64,${imgBuffer.toString("base64")}`;

      const colNum = colLetterToNumber(colLetter);
      imageMap.set(`${rowNum}:${colNum}`, dataUrl);
    }

    console.log(`[PlaceInCell] extracted ${imageMap.size} cell images`);
  } catch (err) {
    console.error("[PlaceInCell] extraction error:", err);
  }

  return imageMap;
}

function buildRows(
  worksheet: ExcelJS.Worksheet,
  columns: ColumnRuntimeMeta[],
  headerRowIndex: number,
  fileId: string,
  imageMap: Map<string, string>,
): ParsedRow[] {
  const rows: ParsedRow[] = [];

  for (
    let rowIndex = headerRowIndex + 1;
    rowIndex <= worksheet.rowCount;
    rowIndex += 1
  ) {
    const row = worksheet.getRow(rowIndex);
    const values: Record<string, ParsedCell> = {};
    let hasData = false;

    for (const column of columns) {
      const imageKey = `${rowIndex}:${column.colNumber}`;
      const imageSrc = imageMap.get(imageKey);
      const rawValue = row.getCell(column.colNumber).value;
      const textValue = normalizeCellText(rawValue);

      if (imageSrc) {
        values[column.key] = textValue
          ? {
              type: "image",
              src: imageSrc,
              value: textValue,
            }
          : {
              type: "image",
              src: imageSrc,
            };
        hasData = true;
        continue;
      }

      if (textValue) {
        hasData = true;
      }

      values[column.key] = {
        type: "text",
        value: textValue,
      };
    }

    if (!hasData) {
      continue;
    }

    rows.push({
      rowId: `${fileId}_${rowIndex}`,
      values,
    });
  }

  return rows;
}

function getLevelOptions(rows: ParsedRow[], columnKey?: string): string[] {
  if (!columnKey) {
    return [];
  }

  const unique = new Set<string>();
  for (const row of rows) {
    const value = row.values[columnKey]?.value?.trim();
    if (value) {
      unique.add(value);
    }
  }
  return Array.from(unique);
}

function validateRequiredColumns(columns: ColumnRuntimeMeta[]): void {
  const hasLevel1 = columns.some((column) =>
    matchesHeader(column.title, LEVEL1_ALIASES),
  );
  const hasLevel2 = columns.some((column) =>
    matchesHeader(column.title, LEVEL2_ALIASES),
  );

  const missing: string[] = [];
  if (!hasLevel1) {
    missing.push("level1");
  }
  if (!hasLevel2) {
    missing.push("level2");
  }

  if (missing.length > 0) {
    throw new Error(`缺少必需列: ${missing.join("、")}`);
  }
}

export async function parseWorkbook(
  buffer: Buffer,
  fileName: string,
  fileId: string,
): Promise<ParsedWorkbook> {
  const workbook = new ExcelJSRuntime.Workbook();
  type ExcelLoadInput = Parameters<ExcelJS.Workbook["xlsx"]["load"]>[0];
  await workbook.xlsx.load(buffer as unknown as ExcelLoadInput);

  const worksheet = workbook.worksheets[0];
  if (!worksheet) {
    throw new Error("Excel 中没有可解析的工作表");
  }

  const headerRowIndex = detectHeaderRow(worksheet);
  const headerRow = worksheet.getRow(headerRowIndex);
  const columns = buildColumns(headerRow);
  if (columns.length === 0) {
    throw new Error("未检测到有效表头");
  }

  validateRequiredColumns(columns);

  // Merge floating images (ExcelJS) + "Place in Cell" images (Excel 365)
  const floatingImageMap = buildImageMap(worksheet, workbook);
  const cellImageMap = await extractPlaceInCellImages(buffer);

  // Cell images take precedence, but merge both
  const imageMap = new Map([...floatingImageMap, ...cellImageMap]);
  console.log(
    `[ImageMap] floating=${floatingImageMap.size}, cellImages=${cellImageMap.size}, total=${imageMap.size}`,
  );
  const rows = buildRows(worksheet, columns, headerRowIndex, fileId, imageMap);

  const level1Key = columns.find((column) =>
    matchesHeader(column.title, LEVEL1_ALIASES),
  )?.key;
  const level2Key = columns.find((column) =>
    matchesHeader(column.title, LEVEL2_ALIASES),
  )?.key;

  return {
    fileId,
    fileName,
    columns: columns.map(({ colNumber: _colNumber, ...column }) => column),
    rows,
    level1Options: getLevelOptions(rows, level1Key),
    level2Options: getLevelOptions(rows, level2Key),
  };
}
