#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

if ! command -v rsync >/dev/null 2>&1; then
  echo "Error: rsync is required but not found." >&2
  exit 1
fi

if ! command -v zip >/dev/null 2>&1; then
  echo "Error: zip is required but not found." >&2
  exit 1
fi

timestamp="$(date +%Y%m%d-%H%M%S)"
default_name="benchmark-code-${timestamp}.zip"
output_name="${1:-$default_name}"

if [[ "$output_name" != *.zip ]]; then
  output_name="${output_name}.zip"
fi

output_path="$PROJECT_ROOT/$output_name"
tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/benchmark-package.XXXXXX")"

cleanup() {
  rm -rf "$tmp_dir"
}
trap cleanup EXIT

rsync -a \
  --exclude-from="$PROJECT_ROOT/.gitignore" \
  --exclude=".git" \
  --exclude="*.zip" \
  --exclude="*.tar.gz" \
  "$PROJECT_ROOT/" "$tmp_dir/"

(
  cd "$tmp_dir"
  zip -rq "$output_path" .
)

archive_size="$(du -h "$output_path" | awk '{print $1}')"
echo "Created zip: $output_path (${archive_size})"
