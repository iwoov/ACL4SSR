import { useEffect, useMemo, useRef, useState } from "react";
import type {
  FileViewState,
  ParsedCell,
  ParsedColumn,
  ParsedFile,
  ParsedRow,
} from "./types";

const ALL_FILTER_VALUE = "全部";
const QUALIFIED_TITLE_ALIASES = ["是否合格"] as const;
const INSPECTOR_TITLE_ALIASES = ["质检员"] as const;
const FEEDBACK_TITLE_ALIASES = ["业务反馈意见", "质检员业务反馈意见"] as const;
const OPENSOURCE_TITLE_ALIASES = ["是否开源"] as const;

function normalizeHeaderTitle(value: string): string {
  return value.replace(/\s+/g, "").toLowerCase();
}

function matchesHeaderAlias(
  title: string,
  aliases: readonly string[],
): boolean {
  const normalizedTitle = normalizeHeaderTitle(title);
  return aliases.some(
    (alias) => normalizeHeaderTitle(alias) === normalizedTitle,
  );
}

function isQualifiedColumnTitle(columnTitle: string): boolean {
  return matchesHeaderAlias(columnTitle, QUALIFIED_TITLE_ALIASES);
}

function isInspectorColumnTitle(columnTitle: string): boolean {
  return matchesHeaderAlias(columnTitle, INSPECTOR_TITLE_ALIASES);
}

function isFeedbackColumnTitle(columnTitle: string): boolean {
  return matchesHeaderAlias(columnTitle, FEEDBACK_TITLE_ALIASES);
}

function isOpensourceColumnTitle(columnTitle: string): boolean {
  return matchesHeaderAlias(columnTitle, OPENSOURCE_TITLE_ALIASES);
}

interface ColumnPrefsConfig {
  fieldSignature: string;
  displayKeys: string[];
  editableKeys: string[];
}

function getFileNameFromDisposition(disposition: string | null): string | null {
  if (!disposition) {
    return null;
  }

  const utf8Match = /filename\*=UTF-8''([^;]+)/i.exec(disposition);
  if (utf8Match?.[1]) {
    try {
      return decodeURIComponent(utf8Match[1]);
    } catch {
      return utf8Match[1];
    }
  }

  const plainMatch = /filename="?([^";]+)"?/i.exec(disposition);
  return plainMatch?.[1] ?? null;
}

function downloadBlob(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

const AUTO_BLOCK_FORMULA_LENGTH = 24;

function getPureInlineFormulaBody(value: string): string | null {
  const trimmed = value.trim();

  if (trimmed.startsWith("$$") && trimmed.endsWith("$$")) {
    return null;
  }
  if (trimmed.startsWith("\\[") && trimmed.endsWith("\\]")) {
    return null;
  }

  if (trimmed.startsWith("$") && trimmed.endsWith("$")) {
    const body = trimmed.slice(1, -1);
    if (!body.includes("$")) {
      return body.trim();
    }
  }

  if (trimmed.startsWith("\\(") && trimmed.endsWith("\\)")) {
    return trimmed.slice(2, -2).trim();
  }

  return null;
}

function shouldAutoDisplayLatex(value: string): boolean {
  const formulaBody = getPureInlineFormulaBody(value);
  return (
    formulaBody !== null && formulaBody.length >= AUTO_BLOCK_FORMULA_LENGTH
  );
}

function toDisplayMathIfNeeded(value: string, forceDisplay: boolean): string {
  if (!forceDisplay) {
    return value;
  }
  const formulaBody = getPureInlineFormulaBody(value);
  if (formulaBody === null) {
    return value;
  }
  return `\\[${formulaBody}\\]`;
}

function deduplicateKeys(keys: string[]): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  for (const key of keys) {
    if (!seen.has(key)) {
      seen.add(key);
      result.push(key);
    }
  }
  return result;
}

function getAllColumnKeys(columns: ParsedColumn[]): string[] {
  return columns.map((column) => column.key);
}

function isFilterColumnTitle(columnTitle: string): boolean {
  const normalized = normalizeHeaderTitle(columnTitle);
  return normalized === "level1" || normalized === "level2";
}

function getFieldSignature(columns: ParsedColumn[]): string {
  return columns.map((column) => normalizeHeaderTitle(column.title)).join("|");
}

function normalizeColumnSelection(
  columns: ParsedColumn[],
  selectedDisplayColumnKeys?: string[],
  selectedEditableColumnKeys?: string[],
): {
  displayKeys: string[];
  editableKeys: string[];
} {
  const allColumnKeys = getAllColumnKeys(columns);
  const allowedKeys = new Set(allColumnKeys);

  const editableKeys = deduplicateKeys(selectedEditableColumnKeys ?? []).filter(
    (key) => allowedKeys.has(key),
  );

  const displaySourceKeys = selectedDisplayColumnKeys ?? allColumnKeys;
  const displaySet = new Set(
    deduplicateKeys(displaySourceKeys).filter((key) => allowedKeys.has(key)),
  );
  editableKeys.forEach((key) => displaySet.add(key));

  return {
    displayKeys: allColumnKeys.filter((key) => displaySet.has(key)),
    editableKeys,
  };
}

function applyEditableConfig(
  columns: ParsedColumn[],
  editableKeys: string[],
): ParsedColumn[] {
  const editableSet = new Set(editableKeys);
  return columns.map((column) => ({
    ...column,
    editable: editableSet.has(column.key),
    required: isFilterColumnTitle(column.title) || editableSet.has(column.key),
  }));
}

function toViewState(
  parsed: ParsedFile,
  selectedDisplayColumnKeys?: string[],
  selectedEditableColumnKeys?: string[],
): FileViewState {
  const normalized = normalizeColumnSelection(
    parsed.columns,
    selectedDisplayColumnKeys,
    selectedEditableColumnKeys,
  );
  return {
    ...parsed,
    columns: applyEditableConfig(parsed.columns, normalized.editableKeys),
    selectedDisplayColumnKeys: normalized.displayKeys,
    selectedEditableColumnKeys: normalized.editableKeys,
    level1Filter: ALL_FILTER_VALUE,
    level2Filter: ALL_FILTER_VALUE,
  };
}

function applyColumnConfigToFile(
  file: FileViewState,
  selectedDisplayColumnKeys: string[],
  selectedEditableColumnKeys: string[],
): FileViewState {
  const normalized = normalizeColumnSelection(
    file.columns,
    selectedDisplayColumnKeys,
    selectedEditableColumnKeys,
  );

  return {
    ...file,
    columns: applyEditableConfig(file.columns, normalized.editableKeys),
    selectedDisplayColumnKeys: normalized.displayKeys,
    selectedEditableColumnKeys: normalized.editableKeys,
  };
}

function getLevelColumnKey(
  columns: ParsedColumn[],
  title: string,
): string | undefined {
  return columns.find((column) => normalizeHeaderTitle(column.title) === title)
    ?.key;
}

function getCellText(row: ParsedRow, columnKey: string): string {
  return row.values[columnKey]?.value ?? "";
}

const LATEX_PATTERN =
  /(\$\$[\s\S]+?\$\$)|((^|[^\\])\$[^$\n]+?\$)|(\\\([\s\S]+?\\\))|(\\\[[\s\S]+?\\\])|(\\(?:frac|sqrt|sum|int|left|right|begin|end|alpha|beta|gamma|delta|theta|lambda|pi|times|cdot|pm|leq|geq|neq)\b)/;

function hasLatexSyntax(value: string): boolean {
  return LATEX_PATTERN.test(value.trim());
}

type MathJaxConfig = {
  tex?: {
    inlineMath?: Array<[string, string]>;
    displayMath?: Array<[string, string]>;
  };
  options?: {
    skipHtmlTags?: string[];
  };
  svg?: {
    fontCache?: string;
  };
  startup?: {
    promise?: Promise<unknown>;
  };
  typesetPromise?: (elements?: Element[]) => Promise<unknown>;
};

declare global {
  interface Window {
    MathJax?: MathJaxConfig;
  }
}

let mathJaxLoadPromise: Promise<void> | null = null;

async function ensureMathJaxLoaded(): Promise<MathJaxConfig | null> {
  if (typeof window === "undefined") {
    return null;
  }

  if (window.MathJax?.typesetPromise) {
    return window.MathJax;
  }

  if (!mathJaxLoadPromise) {
    mathJaxLoadPromise = new Promise<void>((resolve, reject) => {
      const existingScript = document.querySelector<HTMLScriptElement>(
        "script[data-mathjax-loader='true']",
      );

      if (existingScript) {
        if (window.MathJax?.typesetPromise) {
          resolve();
          return;
        }
        existingScript.addEventListener("load", () => resolve(), {
          once: true,
        });
        existingScript.addEventListener(
          "error",
          () => reject(new Error("MathJax 脚本加载失败")),
          { once: true },
        );
        return;
      }

      window.MathJax = window.MathJax ?? {};
      window.MathJax.tex = window.MathJax.tex ?? {
        inlineMath: [
          ["$", "$"],
          ["\\(", "\\)"],
        ],
        displayMath: [
          ["$$", "$$"],
          ["\\[", "\\]"],
        ],
      };
      window.MathJax.options = window.MathJax.options ?? {
        skipHtmlTags: [
          "script",
          "noscript",
          "style",
          "textarea",
          "pre",
          "code",
        ],
      };
      window.MathJax.svg = window.MathJax.svg ?? {
        fontCache: "global",
      };

      const script = document.createElement("script");
      script.src = "https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js";
      script.async = true;
      script.defer = true;
      script.setAttribute("data-mathjax-loader", "true");
      script.onload = () => resolve();
      script.onerror = () => reject(new Error("MathJax 脚本加载失败"));
      document.head.appendChild(script);
    }).catch((error) => {
      mathJaxLoadPromise = null;
      throw error;
    });
  }

  await mathJaxLoadPromise;
  return window.MathJax ?? null;
}

function LatexRenderer({
  value,
  forceDisplay = false,
}: {
  value: string;
  forceDisplay?: boolean;
}) {
  const containerRef = useRef<HTMLSpanElement>(null);
  const [renderFailed, setRenderFailed] = useState(false);

  useEffect(() => {
    let disposed = false;

    const render = async () => {
      const container = containerRef.current;
      if (!container) {
        return;
      }

      container.textContent = toDisplayMathIfNeeded(value, forceDisplay);
      setRenderFailed(false);

      try {
        const mathJax = await ensureMathJaxLoaded();
        if (disposed || !mathJax?.typesetPromise || !containerRef.current) {
          return;
        }

        if (mathJax.startup?.promise) {
          await mathJax.startup.promise;
        }
        await mathJax.typesetPromise([containerRef.current]);
      } catch {
        if (!disposed) {
          setRenderFailed(true);
        }
      }
    };

    void render();
    return () => {
      disposed = true;
    };
  }, [value, forceDisplay]);

  if (renderFailed) {
    return <span className="latex-plain">{value}</span>;
  }

  return <span className="latex-rendered" ref={containerRef} />;
}

/* ─── SVG Icons ─── */
const IconUpload = () => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="17 8 12 3 7 8" />
    <line x1="12" y1="3" x2="12" y2="15" />
  </svg>
);

const IconDownload = () => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="7 10 12 15 17 10" />
    <line x1="12" y1="15" x2="12" y2="3" />
  </svg>
);

const IconFile = () => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14 2 14 8 20 8" />
  </svg>
);

const IconChevron = () => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <polyline points="9 18 15 12 9 6" />
  </svg>
);

const IconSun = () => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="5" />
    <line x1="12" y1="1" x2="12" y2="3" />
    <line x1="12" y1="21" x2="12" y2="23" />
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
    <line x1="1" y1="12" x2="3" y2="12" />
    <line x1="21" y1="12" x2="23" y2="12" />
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
  </svg>
);

const IconMoon = () => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
  </svg>
);

function App() {
  type PendingConfigMode = "import" | "edit";
  const [files, setFiles] = useState<FileViewState[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const [pendingFile, setPendingFile] = useState<ParsedFile | null>(null);
  const [pendingSelectedDisplayKeys, setPendingSelectedDisplayKeys] = useState<
    string[]
  >([]);
  const [pendingEditableColumnKeys, setPendingEditableColumnKeys] = useState<
    string[]
  >([]);
  const [pendingConfigNotice, setPendingConfigNotice] = useState<string>("");
  const [pendingConfigMode, setPendingConfigMode] =
    useState<PendingConfigMode>("import");
  const [showHiddenFields, setShowHiddenFields] = useState(false);
  const [latexRenderOverrides, setLatexRenderOverrides] = useState<
    Record<string, boolean>
  >({});
  const [previewImageSrc, setPreviewImageSrc] = useState<string | null>(null);
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    if (typeof window !== "undefined") {
      return (localStorage.getItem("theme") as "dark" | "light") || "dark";
    }
    return "dark";
  });
  const uploadInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  const activeFile = useMemo(
    () => files.find((item) => item.fileId === activeFileId) ?? null,
    [files, activeFileId],
  );

  const level1ColumnKey = activeFile
    ? getLevelColumnKey(activeFile.columns, "level1")
    : undefined;
  const level2ColumnKey = activeFile
    ? getLevelColumnKey(activeFile.columns, "level2")
    : undefined;

  const displayColumns = useMemo(() => {
    if (!activeFile) {
      return [];
    }
    return activeFile.columns.filter((column) => {
      return activeFile.selectedDisplayColumnKeys.includes(column.key);
    });
  }, [activeFile]);

  const hiddenColumns = useMemo(() => {
    if (!activeFile) {
      return [];
    }
    return activeFile.columns.filter((column) => {
      return !activeFile.selectedDisplayColumnKeys.includes(column.key);
    });
  }, [activeFile]);

  const visibleRows = useMemo(() => {
    if (!activeFile) {
      return [];
    }

    return activeFile.rows.filter((row) => {
      if (level1ColumnKey && activeFile.level1Filter !== ALL_FILTER_VALUE) {
        const value = getCellText(row, level1ColumnKey).trim();
        if (value !== activeFile.level1Filter) {
          return false;
        }
      }

      if (level2ColumnKey && activeFile.level2Filter !== ALL_FILTER_VALUE) {
        const value = getCellText(row, level2ColumnKey).trim();
        if (value !== activeFile.level2Filter) {
          return false;
        }
      }

      return true;
    });
  }, [activeFile, level1ColumnKey, level2ColumnKey]);

  useEffect(() => {
    if (!activeFile || visibleRows.length === 0) {
      setSelectedRowId(null);
      return;
    }

    const selectedStillVisible = selectedRowId
      ? visibleRows.some((row) => row.rowId === selectedRowId)
      : false;

    if (!selectedStillVisible) {
      setSelectedRowId(visibleRows[0].rowId);
    }
  }, [activeFile, visibleRows, selectedRowId]);

  const selectedRow = useMemo(
    () => visibleRows.find((row) => row.rowId === selectedRowId) ?? null,
    [visibleRows, selectedRowId],
  );

  const rowPreviewColumns = useMemo(() => {
    if (!activeFile) {
      return [];
    }

    const preferred = activeFile.columns.filter(
      (column) =>
        normalizeHeaderTitle(column.title) === "level1" ||
        normalizeHeaderTitle(column.title) === "level2" ||
        isQualifiedColumnTitle(column.title),
    );
    const merged = [...preferred, ...displayColumns];
    const uniqueMap = new Map<string, ParsedColumn>();
    merged.forEach((column) => {
      if (!isFeedbackColumnTitle(column.title)) {
        uniqueMap.set(column.key, column);
      }
    });
    return Array.from(uniqueMap.values()).slice(0, 3);
  }, [activeFile, displayColumns]);

  const patchActiveFile = (updater: (file: FileViewState) => FileViewState) => {
    if (!activeFileId) {
      return;
    }
    setFiles((previous) =>
      previous.map((file) =>
        file.fileId === activeFileId ? updater(file) : file,
      ),
    );
  };

  const persistColumnPrefs = (file: FileViewState) => {
    fetch(`/api/column-prefs/${encodeURIComponent(file.fileName)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        fieldSignature: getFieldSignature(file.columns),
        displayKeys: file.selectedDisplayColumnKeys,
        editableKeys: file.selectedEditableColumnKeys,
      }),
    }).catch(() => {});
  };

  const resetPendingConfigState = () => {
    setPendingFile(null);
    setPendingSelectedDisplayKeys([]);
    setPendingEditableColumnKeys([]);
    setPendingConfigNotice("");
    setPendingConfigMode("import");
  };

  const onOpenActiveFileConfig = () => {
    if (!activeFile) {
      return;
    }
    setPendingFile(activeFile);
    setPendingSelectedDisplayKeys(activeFile.selectedDisplayColumnKeys);
    setPendingEditableColumnKeys(activeFile.selectedEditableColumnKeys);
    setPendingConfigNotice("");
    setPendingConfigMode("edit");
  };

  const onExportFile = async () => {
    if (!activeFile) {
      return;
    }

    setIsExporting(true);
    setErrorMessage("");

    try {
      const exportColumns = activeFile.columns;
      const headers = exportColumns.map((column) => column.title);
      const rows = activeFile.rows.map((row) =>
        exportColumns.map((column) => row.values[column.key]?.value ?? ""),
      );

      const response = await fetch("/api/files/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: activeFile.fileName,
          headers,
          rows,
        }),
      });

      if (!response.ok) {
        const payload = (await response.json().catch(() => ({}))) as {
          message?: string;
        };
        throw new Error(payload.message ?? "导出失败");
      }

      const blob = await response.blob();
      const headerFileName = getFileNameFromDisposition(
        response.headers.get("Content-Disposition"),
      );
      const fallbackFileName = `${activeFile.fileName.replace(/\.[^.]+$/, "")}-导出.xlsx`;
      downloadBlob(blob, headerFileName ?? fallbackFileName);
    } catch (error) {
      const message = error instanceof Error ? error.message : "导出失败";
      setErrorMessage(message);
    } finally {
      setIsExporting(false);
    }
  };

  const onUploadClick = () => {
    uploadInputRef.current?.click();
  };

  const onUploadFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0];
    if (!selected) {
      return;
    }

    setIsUploading(true);
    setErrorMessage("");

    try {
      const formData = new FormData();
      formData.append("file", selected);
      const response = await fetch("/api/files/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const payload = (await response.json().catch(() => ({}))) as {
          message?: string;
        };
        throw new Error(payload.message ?? "文件解析失败");
      }

      const parsed = (await response.json()) as ParsedFile;
      const defaultDisplayKeys = getAllColumnKeys(parsed.columns);
      let initialDisplayKeys = defaultDisplayKeys;
      let initialEditableKeys: string[] = [];
      let shouldShowColumnModal = true;
      let nextPendingNotice = "";

      try {
        const prefsRes = await fetch(
          `/api/column-prefs/${encodeURIComponent(parsed.fileName)}`,
        );
        if (prefsRes.ok) {
          const prefsData = (await prefsRes.json()) as {
            config: ColumnPrefsConfig | null;
          };
          if (prefsData.config) {
            const normalizedSaved = normalizeColumnSelection(
              parsed.columns,
              prefsData.config.displayKeys,
              prefsData.config.editableKeys,
            );
            const currentSignature = getFieldSignature(parsed.columns);
            if (prefsData.config.fieldSignature === currentSignature) {
              const nextFile = toViewState(
                parsed,
                normalizedSaved.displayKeys,
                normalizedSaved.editableKeys,
              );
              setFiles((previous) => [...previous, nextFile]);
              setActiveFileId(nextFile.fileId);
              shouldShowColumnModal = false;
            } else {
              nextPendingNotice =
                "检测到该 Excel 字段与已保存配置不一致，请重新选择并保存新配置。";
              initialDisplayKeys = normalizedSaved.displayKeys;
              initialEditableKeys = normalizedSaved.editableKeys;
            }
          }
        }
      } catch {
        // Ignore and fall back to default selection
      }

      if (shouldShowColumnModal) {
        setPendingFile(parsed);
        setPendingSelectedDisplayKeys(initialDisplayKeys);
        setPendingEditableColumnKeys(initialEditableKeys);
        setPendingConfigNotice(nextPendingNotice);
        setPendingConfigMode("import");
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "上传失败";
      setErrorMessage(message);
    } finally {
      setIsUploading(false);
      event.target.value = "";
    }
  };

  const onRemoveFile = (fileId: string) => {
    setFiles((previous) => {
      const next = previous.filter((file) => file.fileId !== fileId);
      if (activeFileId === fileId) {
        setActiveFileId(next[0]?.fileId ?? null);
      }
      return next;
    });
  };

  const onTogglePendingDisplayColumn = (columnKey: string) => {
    if (!pendingFile) {
      return;
    }
    setPendingSelectedDisplayKeys((previous) => {
      const shouldHide = previous.includes(columnKey);
      const next = shouldHide
        ? previous.filter((key) => key !== columnKey)
        : [...previous, columnKey];

      if (shouldHide) {
        setPendingEditableColumnKeys((editableKeys) =>
          editableKeys.filter((key) => key !== columnKey),
        );
      }
      return next;
    });
  };

  const onTogglePendingEditableColumn = (columnKey: string) => {
    if (!pendingFile) {
      return;
    }
    setPendingEditableColumnKeys((previous) => {
      const exists = previous.includes(columnKey);
      const next = exists
        ? previous.filter((key) => key !== columnKey)
        : [...previous, columnKey];

      if (!exists) {
        setPendingSelectedDisplayKeys((displayKeys) =>
          displayKeys.includes(columnKey)
            ? displayKeys
            : [...displayKeys, columnKey],
        );
      }

      return next;
    });
  };

  const onPendingSelectAllDisplayColumns = () => {
    if (!pendingFile) {
      return;
    }
    setPendingSelectedDisplayKeys(getAllColumnKeys(pendingFile.columns));
  };

  const onPendingClearDisplayColumns = () => {
    setPendingSelectedDisplayKeys([]);
    setPendingEditableColumnKeys([]);
  };

  const onPendingClearEditableColumns = () => {
    setPendingEditableColumnKeys([]);
  };

  const onCancelPendingFile = () => {
    resetPendingConfigState();
  };

  const onConfirmPendingFile = () => {
    if (!pendingFile) {
      return;
    }

    if (pendingConfigMode === "edit") {
      patchActiveFile((file) => {
        const nextFile = applyColumnConfigToFile(
          file,
          pendingSelectedDisplayKeys,
          pendingEditableColumnKeys,
        );
        persistColumnPrefs(nextFile);
        return nextFile;
      });
      resetPendingConfigState();
      return;
    }

    const nextFile = toViewState(
      pendingFile,
      pendingSelectedDisplayKeys,
      pendingEditableColumnKeys,
    );
    setFiles((previous) => [...previous, nextFile]);
    setActiveFileId(nextFile.fileId);
    persistColumnPrefs(nextFile);
    resetPendingConfigState();
  };

  const onToggleDisplayColumn = (columnKey: string) => {
    patchActiveFile((file) => {
      if (file.selectedEditableColumnKeys.includes(columnKey)) {
        return file;
      }

      const exists = file.selectedDisplayColumnKeys.includes(columnKey);
      const selectedDisplayColumnKeys = exists
        ? file.selectedDisplayColumnKeys.filter((key) => key !== columnKey)
        : [...file.selectedDisplayColumnKeys, columnKey];

      const normalized = normalizeColumnSelection(
        file.columns,
        selectedDisplayColumnKeys,
        file.selectedEditableColumnKeys,
      );
      const nextFile: FileViewState = {
        ...file,
        selectedDisplayColumnKeys: normalized.displayKeys,
        selectedEditableColumnKeys: normalized.editableKeys,
      };
      persistColumnPrefs(nextFile);
      return nextFile;
    });
  };

  const onFilterChange = (type: "level1" | "level2", value: string) => {
    patchActiveFile((file) => ({
      ...file,
      level1Filter: type === "level1" ? value : file.level1Filter,
      level2Filter: type === "level2" ? value : file.level2Filter,
    }));
  };

  const onEditCell = (rowId: string, columnKey: string, value: string) => {
    patchActiveFile((file) => ({
      ...file,
      rows: file.rows.map((row) => {
        if (row.rowId !== rowId) {
          return row;
        }

        const currentCell = row.values[columnKey];

        return {
          ...row,
          values: {
            ...row.values,
            [columnKey]:
              currentCell?.type === "image" && currentCell.src
                ? {
                    type: "image",
                    src: currentCell.src,
                    value,
                  }
                : {
                    type: "text",
                    value,
                  },
          },
        };
      }),
    }));
  };

  const getLatexToggleKey = (columnKey: string) =>
    activeFileId ? `${activeFileId}::${columnKey}` : columnKey;

  const onToggleLatexRender = (columnKey: string) => {
    const key = getLatexToggleKey(columnKey);
    setLatexRenderOverrides((previous) => ({
      ...previous,
      [key]: !(previous[key] ?? true),
    }));
  };

  const renderReadonlyCell = (
    cell: ParsedCell | undefined,
    shouldRenderLatex: boolean,
  ) => {
    if (!cell) {
      return <span className="empty-text">-</span>;
    }

    if (cell.type === "image" && cell.src) {
      return (
        <div className="image-cell">
          <img
            src={cell.src}
            alt={cell.value || "Excel图片"}
            onClick={() => setPreviewImageSrc(cell.src!)}
          />
          {cell.value ? <span>{cell.value}</span> : null}
        </div>
      );
    }

    const textValue = cell.value ?? "";
    if (cell.type === "text" && textValue.length > 0) {
      const hasLatex = hasLatexSyntax(textValue);
      const autoDisplayLatex = shouldAutoDisplayLatex(textValue);
      if (hasLatex && shouldRenderLatex) {
        return (
          <LatexRenderer value={textValue} forceDisplay={autoDisplayLatex} />
        );
      }
      return hasLatex ? (
        <span className="latex-plain">{textValue}</span>
      ) : (
        <span>{textValue}</span>
      );
    }

    return cell.value ? (
      <span>{cell.value}</span>
    ) : (
      <span className="empty-text">-</span>
    );
  };

  const renderCellContent = (
    row: ParsedRow,
    column: ParsedColumn,
    shouldRenderLatex = true,
  ) => {
    const cell = row.values[column.key];
    if (!column.editable) {
      return renderReadonlyCell(cell, shouldRenderLatex);
    }

    const currentValue = cell?.value ?? "";

    if (isQualifiedColumnTitle(column.title)) {
      const stableOptions = ["", "合格", "不合格"];
      const shouldAppendCurrent =
        currentValue.length > 0 && !stableOptions.includes(currentValue);
      return (
        <select
          className="qualified-select"
          value={currentValue}
          onChange={(event) =>
            onEditCell(row.rowId, column.key, event.target.value)
          }
        >
          <option value="">未填写</option>
          <option value="合格">合格</option>
          <option value="不合格">不合格</option>
          {shouldAppendCurrent ? (
            <option value={currentValue}>{currentValue}</option>
          ) : null}
        </select>
      );
    }

    if (isOpensourceColumnTitle(column.title)) {
      const stableOptions = ["", "是", "否"];
      const shouldAppendCurrent =
        currentValue.length > 0 && !stableOptions.includes(currentValue);
      return (
        <select
          className="qualified-select"
          value={currentValue}
          onChange={(event) =>
            onEditCell(row.rowId, column.key, event.target.value)
          }
        >
          <option value="">未填写</option>
          <option value="是">是</option>
          <option value="否">否</option>
          {shouldAppendCurrent ? (
            <option value={currentValue}>{currentValue}</option>
          ) : null}
        </select>
      );
    }

    if (isInspectorColumnTitle(column.title)) {
      return (
        <input
          className="inspector-input"
          value={currentValue}
          onChange={(event) =>
            onEditCell(row.rowId, column.key, event.target.value)
          }
          placeholder="请输入质检员"
        />
      );
    }

    if (isFeedbackColumnTitle(column.title)) {
      return (
        <textarea
          className="feedback-input"
          value={currentValue}
          onChange={(event) =>
            onEditCell(row.rowId, column.key, event.target.value)
          }
          placeholder="请输入质检反馈意见"
        />
      );
    }

    if (cell?.type === "image" && cell.src) {
      return (
        <div className="image-cell">
          <img
            src={cell.src}
            alt={cell.value || "Excel图片"}
            onClick={() => setPreviewImageSrc(cell.src!)}
          />
          <input
            className="editable-text-input"
            value={currentValue}
            onChange={(event) =>
              onEditCell(row.rowId, column.key, event.target.value)
            }
            placeholder={`请输入${column.title}`}
          />
        </div>
      );
    }

    return (
      <input
        className="editable-text-input"
        value={currentValue}
        onChange={(event) =>
          onEditCell(row.rowId, column.key, event.target.value)
        }
        placeholder={`请输入${column.title}`}
      />
    );
  };

  const renderDetailField = (column: ParsedColumn, isHidden = false) => {
    if (!selectedRow) return null;
    const isRequired = column.editable;
    const isChecked = !isHidden;
    const cell = selectedRow.values[column.key];
    const hasLatex =
      !column.editable &&
      !isHidden &&
      cell?.type === "text" &&
      typeof cell.value === "string" &&
      hasLatexSyntax(cell.value);
    const latexToggleKey = getLatexToggleKey(column.key);
    const isLatexRenderingEnabled =
      latexRenderOverrides[latexToggleKey] ?? true;

    return (
      <div
        key={`${selectedRow.rowId}_${column.key}`}
        className={`detail-field ${isHidden ? "hidden-field" : ""}`}
      >
        <div className="detail-label">
          <button
            type="button"
            className={`field-toggle ${isRequired ? "locked" : ""} ${isChecked ? "checked" : ""}`}
            onClick={() => {
              if (!isRequired) {
                onToggleDisplayColumn(column.key);
              }
            }}
            title={
              isRequired
                ? "可编辑字段必须展示"
                : isHidden
                  ? "点击显示此字段"
                  : "点击隐藏此字段"
            }
          />
          <div className="field-name-wrap">
            <span className="field-name">{column.title}</span>
            {hasLatex ? (
              <label
                className="latex-toggle"
                title="控制该字段是否按 LaTeX 公式渲染"
              >
                <input
                  type="checkbox"
                  checked={isLatexRenderingEnabled}
                  onChange={() => onToggleLatexRender(column.key)}
                  aria-label={`${column.title} 的 LaTeX 渲染开关`}
                />
                <span>LaTeX渲染</span>
              </label>
            ) : null}
          </div>
          {column.editable ? (
            <span className="field-badge badge-editable">可编辑</span>
          ) : null}
          {isRequired ? (
            <span className="field-badge badge-locked">必显</span>
          ) : null}
        </div>
        {!isHidden ? (
          <div className="detail-value">
            {renderCellContent(selectedRow, column, isLatexRenderingEnabled)}
          </div>
        ) : null}
      </div>
    );
  };

  return (
    <div className="app-shell">
      {/* ─── Header Bar ─── */}
      <header className="header-bar">
        <div className="header-inner">
          <div className="header-brand">
            <div className="brand-icon">
              <svg viewBox="0 0 24 24">
                <path
                  d="M9 2L4 7v13a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H9zm0 0v5H4m4 4h8m-8 4h8m-8 4h4"
                  fill="none"
                  stroke="white"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <h1>质检工作台</h1>
          </div>

          {/* ─── File Tabs ─── */}
          <div className="file-tabs">
            {files.map((file) => (
              <div
                key={file.fileId}
                className={`file-tab ${file.fileId === activeFileId ? "active" : ""}`}
              >
                <button
                  type="button"
                  style={{
                    all: "unset",
                    cursor: "pointer",
                    display: "contents",
                  }}
                  onClick={() => setActiveFileId(file.fileId)}
                >
                  {file.fileName}
                </button>
                <span className="tab-badge">{file.rows.length}</span>
                <button
                  type="button"
                  className="tab-close"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemoveFile(file.fileId);
                  }}
                  title="关闭"
                >
                  ×
                </button>
              </div>
            ))}
          </div>

          {/* ─── Header Actions ─── */}
          <div className="header-actions">
            {errorMessage ? (
              <span className="error-text">{errorMessage}</span>
            ) : null}
            <button
              type="button"
              className="theme-toggle"
              onClick={toggleTheme}
              title={theme === "dark" ? "切换浅色主题" : "切换深色主题"}
            >
              {theme === "dark" ? <IconSun /> : <IconMoon />}
            </button>
            <button
              type="button"
              className="btn"
              onClick={onOpenActiveFileConfig}
              disabled={!activeFile}
            >
              字段配置
            </button>
            <button
              type="button"
              className="btn"
              onClick={onExportFile}
              disabled={isExporting || !activeFile}
            >
              <IconDownload />
              {isExporting ? "导出中..." : "导出 Excel"}
            </button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={onUploadClick}
              disabled={isUploading}
            >
              <IconUpload />
              {isUploading ? "解析中..." : "导入 Excel"}
            </button>
            <input
              ref={uploadInputRef}
              type="file"
              accept=".xls,.xlsx"
              className="hidden-input"
              onChange={onUploadFile}
            />
          </div>
        </div>
      </header>

      {/* ─── Main Content ─── */}
      <main className="main-content">
        {!activeFile ? (
          <section className="placeholder">
            <div className="placeholder-icon">
              <IconFile />
            </div>
            <h2>等待文件导入</h2>
            <p>
              点击右上角「导入
              Excel」按钮，支持展示/可编辑字段配置、level1/level2筛选、图片展示与导出。
            </p>
          </section>
        ) : (
          <>
            {/* ─── Toolbar ─── */}
            <section className="toolbar">
              <div className="filter-group">
                <label htmlFor="level1-filter">level1</label>
                <select
                  id="level1-filter"
                  value={activeFile.level1Filter}
                  onChange={(event) =>
                    onFilterChange("level1", event.target.value)
                  }
                >
                  <option value={ALL_FILTER_VALUE}>{ALL_FILTER_VALUE}</option>
                  {activeFile.level1Options.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>
              <div className="filter-group">
                <label htmlFor="level2-filter">level2</label>
                <select
                  id="level2-filter"
                  value={activeFile.level2Filter}
                  onChange={(event) =>
                    onFilterChange("level2", event.target.value)
                  }
                >
                  <option value={ALL_FILTER_VALUE}>{ALL_FILTER_VALUE}</option>
                  {activeFile.level2Options.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>
              <div className="stats">
                <strong>{visibleRows.length}</strong>
                <span>筛选后行数</span>
              </div>
            </section>

            {/* ─── Detail Layout ─── */}
            <section className="detail-layout">
              {/* ─── Record List ─── */}
              <aside className="record-list">
                <div className="record-list-header">
                  <h3>数据列表</h3>
                  <p>选择一条数据，右侧查看并编辑详情</p>
                </div>
                {visibleRows.length === 0 ? (
                  <div className="record-list-empty">当前筛选条件下无数据</div>
                ) : (
                  <div className="record-list-items">
                    {visibleRows.map((row, index) => {
                      const preview = rowPreviewColumns
                        .map((column) => {
                          const value = row.values[column.key]?.value?.trim();
                          return `${column.title}: ${value || "-"}`;
                        })
                        .join(" ｜ ");
                      return (
                        <button
                          key={row.rowId}
                          type="button"
                          className={`record-item ${selectedRowId === row.rowId ? "active" : ""}`}
                          onClick={() => setSelectedRowId(row.rowId)}
                        >
                          <strong>第 {index + 1} 条</strong>
                          <span>{preview}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </aside>

              {/* ─── Record Detail ─── */}
              <section className="record-detail">
                <div className="record-detail-header">
                  <h3>字段详情</h3>
                  {selectedRow ? (
                    <span>点击字段左侧勾选框可控制显示/隐藏</span>
                  ) : null}
                </div>
                {!selectedRow ? (
                  <div className="no-data">请选择一条数据</div>
                ) : (
                  <div className="detail-fields">
                    {/* Visible fields */}
                    {displayColumns.map((column) =>
                      renderDetailField(column, false),
                    )}

                    {/* Hidden fields section */}
                    {hiddenColumns.length > 0 ? (
                      <div className="hidden-fields-section">
                        <button
                          type="button"
                          className={`hidden-fields-toggle ${showHiddenFields ? "expanded" : ""}`}
                          onClick={() => setShowHiddenFields(!showHiddenFields)}
                        >
                          <IconChevron />
                          <span>{hiddenColumns.length} 个已隐藏字段</span>
                        </button>
                        {showHiddenFields ? (
                          <div className="hidden-fields-list">
                            {hiddenColumns.map((column) =>
                              renderDetailField(column, true),
                            )}
                          </div>
                        ) : null}
                      </div>
                    ) : null}
                  </div>
                )}
              </section>
            </section>
          </>
        )}
      </main>

      {/* ─── Column Selection Modal ─── */}
      {pendingFile ? (
        <div className="column-modal-mask">
          <div className="column-modal">
            <h3>
              {pendingConfigMode === "edit"
                ? "编辑字段展示与可编辑"
                : "配置字段展示与可编辑"}
            </h3>
            <p>{pendingFile.fileName}</p>
            {pendingConfigNotice ? (
              <div className="column-modal-notice">{pendingConfigNotice}</div>
            ) : null}
            <div className="column-modal-actions">
              <button
                type="button"
                className="btn"
                onClick={onPendingSelectAllDisplayColumns}
              >
                全选展示
              </button>
              <button
                type="button"
                className="btn"
                onClick={onPendingClearDisplayColumns}
              >
                清空展示
              </button>
              <button
                type="button"
                className="btn"
                onClick={onPendingClearEditableColumns}
              >
                清空可编辑
              </button>
            </div>
            <div className="column-modal-list">
              {pendingFile.columns.map((column) => {
                const checkedDisplay = pendingSelectedDisplayKeys.includes(
                  column.key,
                );
                const checkedEditable = pendingEditableColumnKeys.includes(
                  column.key,
                );
                return (
                  <div
                    key={column.key}
                    className={`column-config-row ${checkedEditable ? "editable-column-row" : ""}`}
                  >
                    <span className="column-config-name">{column.title}</span>
                    <label className="column-config-switch">
                      <input
                        type="checkbox"
                        checked={checkedDisplay}
                        onChange={() =>
                          onTogglePendingDisplayColumn(column.key)
                        }
                      />
                      <span>展示</span>
                    </label>
                    <label className="column-config-switch">
                      <input
                        type="checkbox"
                        checked={checkedEditable}
                        onChange={() =>
                          onTogglePendingEditableColumn(column.key)
                        }
                      />
                      <span>可编辑</span>
                    </label>
                  </div>
                );
              })}
            </div>
            <div className="column-modal-footer">
              <button
                type="button"
                className="btn"
                onClick={onCancelPendingFile}
              >
                取消导入
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={onConfirmPendingFile}
              >
                {pendingConfigMode === "edit" ? "保存配置" : "确认并保存配置"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* ─── Image Lightbox ─── */}
      {previewImageSrc ? (
        <div
          className="lightbox-mask"
          onClick={() => setPreviewImageSrc(null)}
          onKeyDown={(e) => {
            if (e.key === "Escape") setPreviewImageSrc(null);
          }}
          role="button"
          tabIndex={0}
        >
          <img
            className="lightbox-image"
            src={previewImageSrc}
            alt="预览大图"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            type="button"
            className="lightbox-close"
            onClick={() => setPreviewImageSrc(null)}
          >
            ×
          </button>
        </div>
      ) : null}
    </div>
  );
}

export default App;
